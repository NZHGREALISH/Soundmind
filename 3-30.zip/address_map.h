/* I/O device addresses */

#define LEDR_BASE             0xFF200000
#define HEX3_HEX0_BASE        0xFF200020
#define SW_BASE               0xFF200040
